/*
 * QtTestApp.cpp
 *
 *  Created on: May 17, 2013
 *      Author: ahmad
 */

#include "QtTestApp.h"
#include <QtGui>
#include <QProcess>
#include <QApplication>

QtTestApp::QtTestApp(QWidget *parent) : QDialog(parent)
{
    setupUi(this); // this sets up GUI
    connect ( pushButton_browse, SIGNAL( clicked() ), this, SLOT( getPath() ) );
    connect ( pushButton_do, SIGNAL( clicked() ), this, SLOT( doSomething() ) );
    connect ( pushButton_clear, SIGNAL( clicked() ), this, SLOT( clear() ) );
    connect ( pushButton_about, SIGNAL( clicked() ), this, SLOT( about() ) );
    connect ( pushButton_close, SIGNAL( clicked() ), this, SLOT( closew() ) ); 
}

void QtTestApp::getPath()
{
    QString path;

    path = QFileDialog::getOpenFileName(
        this,
        "Choose a file to open",
        QString::null,
        QString::null);

    lineEdit->setText( path );
}

void QtTestApp::doSomething()
{
    int value1, value2;
    Qt::CheckState state;
    QString str;

    textEdit->append( "Path to file: " + lineEdit->text() );

    value1 = spinBox1->value();
    value2 = spinBox2->value();

    textEdit->append( "Number 1 value: " + QString::number(value1) );
    textEdit->append( "Number 2 value: " + QString::number(value2) );

    state = checkBox->checkState();

    str = "Checkbox says: ";
    if ( state == Qt::Checked ) str += "yes";
    else str += "no";
    textEdit->append( str );

    textEdit->append( "ComboBox current text: " + comboBox->currentText() );
    textEdit->append( "ComboBox current item: " + QString::number(comboBox->currentIndex()) );
}

void QtTestApp::clear()
{
    textEdit->clear();
}

void QtTestApp::about()
{
    QMessageBox::about(this,"About UAVNetS",
                "UAVNetS is a open source UAV Network Simulator developed in OMNeT++.\n\n"
                "(c) University of Toledo.\n");
}

void QtTestApp::closew()
{

QProcess ps;
ps.startDetached("omnetpp");
this->close();
//if(ps.atEnd())
//{this->show();}

}





