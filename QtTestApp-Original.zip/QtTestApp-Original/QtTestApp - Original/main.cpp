#include <QApplication>
#include "QtTestApp.h"

int main(int argc, char *argv[])
{
    QApplication app(argc, argv);
    QtTestApp *dialog = new QtTestApp;
    //Dialog w;
    dialog->show();
    return app.exec();
}

