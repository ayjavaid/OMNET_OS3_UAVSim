/********************************************************************************
** Form generated from reading UI file 'UAVNetS.ui'
**
** Created: Fri Jun 7 14:37:56 2013
**      by: Qt User Interface Compiler version 4.8.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_UAVNETS_H
#define UI_UAVNETS_H

#include <QtCore/QVariant>
#include <QtGui/QAction>
#include <QtGui/QApplication>
#include <QtGui/QButtonGroup>
#include <QtGui/QCheckBox>
#include <QtGui/QComboBox>
#include <QtGui/QDialog>
#include <QtGui/QHeaderView>
#include <QtGui/QLabel>
#include <QtGui/QLineEdit>
#include <QtGui/QPushButton>
#include <QtGui/QSpinBox>
#include <QtGui/QTextEdit>

QT_BEGIN_NAMESPACE

class Ui_UAVNetS
{
public:
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QCheckBox *checkBox;
    QTextEdit *textEdit;
    QPushButton *pushButton_browse;
    QSpinBox *spinBox1;
    QSpinBox *spinBox2;
    QComboBox *comboBox;
    QPushButton *pushButton_do;
    QPushButton *pushButton_clear;
    QPushButton *pushButton_about;
    QLineEdit *lineEdit;
    QPushButton *pushButton_close;

    void setupUi(QDialog *UAVNetS)
    {
        if (UAVNetS->objectName().isEmpty())
            UAVNetS->setObjectName(QString::fromUtf8("UAVNetS"));
        UAVNetS->resize(630, 373);
        label = new QLabel(UAVNetS);
        label->setObjectName(QString::fromUtf8("label"));
        label->setGeometry(QRect(30, 70, 71, 17));
        label_2 = new QLabel(UAVNetS);
        label_2->setObjectName(QString::fromUtf8("label_2"));
        label_2->setGeometry(QRect(30, 40, 66, 17));
        label_3 = new QLabel(UAVNetS);
        label_3->setObjectName(QString::fromUtf8("label_3"));
        label_3->setGeometry(QRect(30, 110, 66, 17));
        checkBox = new QCheckBox(UAVNetS);
        checkBox->setObjectName(QString::fromUtf8("checkBox"));
        checkBox->setGeometry(QRect(230, 70, 97, 22));
        textEdit = new QTextEdit(UAVNetS);
        textEdit->setObjectName(QString::fromUtf8("textEdit"));
        textEdit->setGeometry(QRect(30, 140, 571, 161));
        pushButton_browse = new QPushButton(UAVNetS);
        pushButton_browse->setObjectName(QString::fromUtf8("pushButton_browse"));
        pushButton_browse->setGeometry(QRect(490, 30, 98, 27));
        spinBox1 = new QSpinBox(UAVNetS);
        spinBox1->setObjectName(QString::fromUtf8("spinBox1"));
        spinBox1->setGeometry(QRect(110, 70, 60, 27));
        spinBox2 = new QSpinBox(UAVNetS);
        spinBox2->setObjectName(QString::fromUtf8("spinBox2"));
        spinBox2->setGeometry(QRect(110, 100, 60, 27));
        comboBox = new QComboBox(UAVNetS);
        comboBox->setObjectName(QString::fromUtf8("comboBox"));
        comboBox->setGeometry(QRect(200, 100, 78, 27));
        pushButton_do = new QPushButton(UAVNetS);
        pushButton_do->setObjectName(QString::fromUtf8("pushButton_do"));
        pushButton_do->setGeometry(QRect(30, 320, 101, 27));
        pushButton_clear = new QPushButton(UAVNetS);
        pushButton_clear->setObjectName(QString::fromUtf8("pushButton_clear"));
        pushButton_clear->setGeometry(QRect(190, 320, 98, 27));
        pushButton_about = new QPushButton(UAVNetS);
        pushButton_about->setObjectName(QString::fromUtf8("pushButton_about"));
        pushButton_about->setGeometry(QRect(340, 320, 98, 27));
        lineEdit = new QLineEdit(UAVNetS);
        lineEdit->setObjectName(QString::fromUtf8("lineEdit"));
        lineEdit->setGeometry(QRect(70, 30, 391, 27));
        pushButton_close = new QPushButton(UAVNetS);
        pushButton_close->setObjectName(QString::fromUtf8("pushButton_close"));
        pushButton_close->setGeometry(QRect(490, 320, 98, 27));
        pushButton_close->setStyleSheet(QString::fromUtf8("background-color: rgb(255, 170, 121);\n"
"border-color: rgb(255, 172, 103);"));
        pushButton_close->setDefault(true);

        retranslateUi(UAVNetS);

        QMetaObject::connectSlotsByName(UAVNetS);
    } // setupUi

    void retranslateUi(QDialog *UAVNetS)
    {
        UAVNetS->setWindowTitle(QApplication::translate("UAVNetS", "UAVNetS", 0, QApplication::UnicodeUTF8));
        label->setText(QApplication::translate("UAVNetS", "Number 1", 0, QApplication::UnicodeUTF8));
        label_2->setText(QApplication::translate("UAVNetS", "File", 0, QApplication::UnicodeUTF8));
        label_3->setText(QApplication::translate("UAVNetS", "Number 2", 0, QApplication::UnicodeUTF8));
        checkBox->setText(QApplication::translate("UAVNetS", "Yes or No", 0, QApplication::UnicodeUTF8));
        pushButton_browse->setText(QApplication::translate("UAVNetS", "Browse", 0, QApplication::UnicodeUTF8));
        comboBox->clear();
        comboBox->insertItems(0, QStringList()
         << QApplication::translate("UAVNetS", "Apple", 0, QApplication::UnicodeUTF8)
         << QApplication::translate("UAVNetS", "Banana", 0, QApplication::UnicodeUTF8)
        );
        pushButton_do->setText(QApplication::translate("UAVNetS", "Show Results", 0, QApplication::UnicodeUTF8));
        pushButton_clear->setText(QApplication::translate("UAVNetS", "Clear", 0, QApplication::UnicodeUTF8));
        pushButton_about->setText(QApplication::translate("UAVNetS", "About", 0, QApplication::UnicodeUTF8));
        pushButton_close->setText(QApplication::translate("UAVNetS", "Close", 0, QApplication::UnicodeUTF8));
    } // retranslateUi

};

namespace Ui {
    class UAVNetS: public Ui_UAVNetS {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_UAVNETS_H
