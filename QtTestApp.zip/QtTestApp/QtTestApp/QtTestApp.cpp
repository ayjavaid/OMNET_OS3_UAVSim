/*
 * QtTestApp.cpp
 *
 *  Created on: May 17, 2013
 *      Author: ahmad
 */

#include "QtTestApp.h"
#include <QtGui>
#include <QProcess>
#include <QApplication>
#include <QFile>
#include <QCoreApplication>
#include <QTextStream>

QtTestApp::QtTestApp(QWidget *parent) : QDialog(parent)
{
    setupUi(this); // this sets up GUI
    connect ( pushButton_browse, SIGNAL( clicked() ), this, SLOT( getPath() ) );
    connect ( pushButton_do, SIGNAL( clicked() ), this, SLOT( doSomething() ) );
    connect ( pushButton_clear, SIGNAL( clicked() ), this, SLOT( clear() ) );
    connect ( pushButton_about, SIGNAL( clicked() ), this, SLOT( about() ) );
    connect ( pushButton_close, SIGNAL( clicked() ), this, SLOT( closew() ) ); 
}

void QtTestApp::getPath()
{
    QString path;

    path = QFileDialog::getOpenFileName(
        this,
        "Choose a file to open",
        QString::null,
        QString::null);

    lineEdit->setText( path );
}

void QtTestApp::doSomething()
{
    int value1, value2;
    Qt::CheckState state;
    QString str;

    textEdit->append( "Path to file: " + lineEdit->text() );

    value1 = spinBox1->value();
    value2 = spinBox2->value();

    textEdit->append( "Number 1 value: " + QString::number(value1) );
    textEdit->append( "Number 2 value: " + QString::number(value2) );

    state = checkBox->checkState();

    str = "Checkbox says: ";
    if ( state == Qt::Checked ) str += "yes";
    else str += "no";
    textEdit->append( str );

    textEdit->append( "ComboBox current text: " + comboBox->currentText() );
    textEdit->append( "ComboBox current item: " + QString::number(comboBox->currentIndex()) );

    QFile file("/home/ahmad/Desktop/test.ini");
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream out(&file);
    out << "[General]\n";
    out << "network = Net80211\n";
    out << "#record-eventlog = true\n";
    out << "Number 1 value: " + QString::number(value1) + "\n";
    out << "Number 2 value: " + QString::number(value2) + "\n";
    out << "\n";
    out << "\n";
    out << "\n";

 
    // optional, as QFile destructor will already do it:
    file.close(); 
 
    //this would normally start the event loop, but is not needed for this
    //minimal example:
    //return app.exec();

}

void QtTestApp::clear()
{
    textEdit->clear();
}

void QtTestApp::about()
{
    QMessageBox::about(this,"About UAVNetS",
                "UAVNetS is a open source UAV Network Simulator developed in OMNeT++.\n\n"
                "(c) University of Toledo.\n");
}

void QtTestApp::closew()
{

QProcess ps;
ps.startDetached("omnetpp");
this->close();
//if(ps.atEnd())
//{this->show();}

}





