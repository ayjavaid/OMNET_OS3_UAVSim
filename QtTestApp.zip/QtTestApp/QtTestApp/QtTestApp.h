/*
 * QtTestApp.h
 *
 *  Created on: May 17, 2013
 *      Author: ahmad
 */

#ifndef QTTESTAPP_H_
#define QTTESTAPP_H_
#include <QDialog>
#include <QProcess>
#include<QMessageBox>
#include "ui_UAVNetS.h"
namespace Ui {
    class UAVNetS;
}
class QtTestApp : public QDialog, public Ui::UAVNetS
{
    Q_OBJECT

//public:
 //  explicit QtTestApp(QDialog *parent = 0);

public:
     QtTestApp(QWidget *parent = 0);
    //~Dialog();
private:
    Ui::UAVNetS *ui;
    QProcess ps;
    QString output;

public slots:
    void getPath();
    void doSomething();
    void clear();
    void about();
    void closew();
};

#endif /* QTTESTAPP_H_ */
